//
//  ViewController.swift
//  PersonData
//
//  Created by Alok Upadhyay on 3/28/18.
//  Copyright © 2018 Alok. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

  @IBOutlet weak var tableView: UITableView!
  
//  var people: [NSManagedObject] = []

  
  @IBAction func addName(_ sender: Any) {
    
    let alert = UIAlertController(title: "New Name",
                                  message: "Add a new name",
                                  preferredStyle: .alert)
    
    
    alert.addTextField(configurationHandler: { (textFieldName) in
      textFieldName.placeholder = "name"
    })
    
    alert.addTextField(configurationHandler: { (textFieldSSN) in
      
      textFieldSSN.placeholder = "ssn"
    })
    
    let saveAction = UIAlertAction(title: "Save", style: .default) { [unowned self] action in
      
      guard let textField = alert.textFields?.first,
        let nameToSave = textField.text else {
          return
      }
      
      guard let textFieldSSN = alert.textFields?[1],
        let SSNToSave = textFieldSSN.text else {
          return
      }
      
      self.save(name: nameToSave, ssn: Int16(SSNToSave)!)
      self.tableView.reloadData()
    }
    
    let cancelAction = UIAlertAction(title: "Cancel",
                                     style: .default)
    
    alert.addAction(saveAction)
    alert.addAction(cancelAction)
    
    present(alert, animated: true)
  }
  
  //insert
  func save(name: String, ssn : Int16) {
    
    let _ = CoreDataManager.sharedManager.insertPerson(name: name, ssn: ssn)
}
  
  @IBAction func deleteAction(_ sender: Any) {
    
    /*init alert controller with title and message*/
    let alert = UIAlertController(title: "Delete by ssn", message: "Enter ssn", preferredStyle: .alert)
    
    /*configure delete action*/
    let deleteAction = UIAlertAction(title: "Delete", style: .default) { [unowned self] action in
      guard let textField = alert.textFields?.first , let itemToDelete = textField.text else {
        return
      }
      /*pass ssn number to delete(:) method*/
      self.delete(ssn: itemToDelete)
    }
    
    /*configure cancel action*/
    let cancelAciton = UIAlertAction(title: "Cancel", style: .default)
    
    /*add text field*/
    alert.addTextField()
    /*add actions*/
    
    alert.addAction(deleteAction)
    alert.addAction(cancelAciton)
    
    present(alert, animated: true, completion: nil)
  }
  
  func delete(ssn: String) {
    
    let _ = CoreDataManager.sharedManager.delete(ssn: ssn)
  }
  
  /*init fetchedResultsController and set self as delegate, also you need to implement delegate methods*/
  func fetchAllPersons(){

    /*This class is delegate of fetchedResultsController protocol methods*/
    CoreDataManager.sharedManager.fetchedResultsController.delegate = self
    do{
      
      print("2. NSFetchResultController will start fetching :)")
      /*initiate performFetch() call on fetchedResultsController*/
      try CoreDataManager.sharedManager.fetchedResultsController.performFetch()
      print("3. NSFetchResultController did end fetching :)")

    }catch{
      print(error)
    }
    
  }
  
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    fetchAllPersons()
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view, typically from a nib.
    tableView.register(UITableViewCell.self,
                       forCellReuseIdentifier: "Cell")
    
  }
  
  func delete(person : Person){
    CoreDataManager.sharedManager.delete(person: person)
  }
  
  func update(name:String, ssn : Int16, person : Person) {
    CoreDataManager.sharedManager.update(name: name, ssn: ssn, person: person)
  }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
  
  func tableView(_ tableView: UITableView,
                 numberOfRowsInSection section: Int) -> Int {
    
    /*fetchResultController's .section method returns array of NSFetchedResultsSectionInfo objects. As we have not provided any section info, sections */
    guard let sections = CoreDataManager.sharedManager.fetchedResultsController.sections else {
      return 0
    }
    
    /*get number of rows count for each section*/
    let sectionInfo = sections[section]
    return sectionInfo.numberOfObjects

  }
  
  func tableView(_ tableView: UITableView,
                 cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    let cell = tableView.dequeueReusableCell(withIdentifier: "Cell",
                                             for: indexPath)
    configureCell(cell, at: indexPath)
    return cell
}
  
  func configureCell(_ cell: UITableViewCell, at indexPath: IndexPath) {
    
    /*get managed object*/
    let person = CoreDataManager.sharedManager.fetchedResultsController.object(at: indexPath)

    // Configure Cell
    cell.textLabel?.text = person.name
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
    /*get managed object*/
    let person = CoreDataManager.sharedManager.fetchedResultsController.object(at: indexPath)

    
    /*initialize alert controller*/
    let alert = UIAlertController(title: "Update Name",
                                  message: "Update Name",
                                  preferredStyle: .alert)
    
    /*add name textfield*/
    alert.addTextField(configurationHandler: { (textFieldName) in
      
      /*set name as plaveholder in textfield*/
      textFieldName.placeholder = "name"
      
      /*use key value coding to get value for key "name" and set it as text of UITextField.*/
      textFieldName.text = person.value(forKey: "name") as? String
      
    })
    
    /*add ssn textfield*/
    alert.addTextField(configurationHandler: { (textFieldSSN) in
      
      /*set ssn as plaveholder in textfield*/
      textFieldSSN.placeholder = "ssn"
      
      /*use key value coding to get value for key "ssn" and set it as text of UITextField.*/
      
      textFieldSSN.text = "\(person.value(forKey: "ssn") as? Int16 ?? 0)"
    })
    
    /*configure update event*/
    let updateAction = UIAlertAction(title: "Update", style: .default) { [unowned self] action in
      
      guard let textField = alert.textFields?[0],
        let nameToSave = textField.text else {
          return
      }
      
      guard let textFieldSSN = alert.textFields?[1],
        let SSNToSave = textFieldSSN.text else {
          return
      }
      
      /*imp part, responsible for update, pass nameToSave and SSn to update: method.*/
      self.update(name : nameToSave, ssn: Int16(SSNToSave)!, person : person as! Person)
    }
    
    /*configure delete event*/
    let deleteAction = UIAlertAction(title: "Delete", style: .default) { [unowned self] action in
      
      /*look at implementation of delete method */
      
      self.delete(person : person as! Person)
      
//      /*remove person object from array also, so that datasource have correct data*/
//      self.people.remove(at: (self.people.index(of: person))!)
//
//      /*Finally reload tableview*/
//      self.tableView.reloadData()
      
    }
    
    /*configure cancel action*/
    let cancelAction = UIAlertAction(title: "Cancel",
                                     style: .default)
    
    /*add all the actions*/
    alert.addAction(updateAction)
    alert.addAction(cancelAction)
    alert.addAction(deleteAction)
    
    /*finally present*/
    present(alert, animated: true)
    
  }
}

extension ViewController  : NSFetchedResultsControllerDelegate{
  
  func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    /*This delegate method will be called first.As the name of this method "controllerWillChangeContent" suggets write some logic for table view to initiate insert row or delete row or update row process. After beginUpdates method the next call will be for :
     
     - (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject atIndexPath:(nullable NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type newIndexPath:(nullable NSIndexPath *)newIndexPath
     
     */
    print("A. NSFetchResultController controllerWillChangeContent :)")

    tableView.beginUpdates()
  }
  
  /*This delegate method will be called second. This method will give information about what operation exactly started taking place a insert, a update, a delete or a move. The enum NSFetchedResultsChangeType will provide the change types.
   
   
   public enum NSFetchedResultsChangeType : UInt {
   
   case insert
   
   case delete
   
   case move
   
   case update
   }
   
   */
  func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
    
    print("B. NSFetchResultController didChange NSFetchedResultsChangeType \(type.rawValue):)")

    
    switch (type) {
    case .insert:
      if let indexPath = newIndexPath {
        tableView.insertRows(at: [indexPath], with: .fade)
      }
      break;
    case .delete:
      if let indexPath = indexPath {
        tableView.deleteRows(at: [indexPath], with: .fade)
      }
      break;
    case .update:
      if let indexPath = indexPath, let cell = tableView.cellForRow(at: indexPath) {
        configureCell(cell, at: indexPath)
      }
      break;
      
    case .move:
      if let indexPath = indexPath {
        tableView.deleteRows(at: [indexPath], with: .fade)
      }
      
      if let newIndexPath = newIndexPath {
        tableView.insertRows(at: [newIndexPath], with: .fade)
      }
      break;
      
  }
}
  
  /*The last delegate call*/
  func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    /*finally balance beginUpdates with endupdates*/
    tableView.endUpdates()
  }
}
